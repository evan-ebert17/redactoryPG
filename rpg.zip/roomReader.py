import rooms

currentRoom = [];