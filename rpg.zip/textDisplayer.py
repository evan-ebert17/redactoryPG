import rooms

currentDescription = []

for letter in currentDescription:
    print(letter)
